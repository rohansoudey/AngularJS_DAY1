import { Component,OnInit,Input,SimpleChanges,OnDestroy,OnChanges } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1>Hello</h1>`,
})
export class AppComponent  {
	
	constructor(){}
	
	ngOnDestroy():void
	{
		console.log("Component Destroyed");
	}
	
	ngOnInit():void
	{
		console.log("Component Initialised");
	}
	
	
	
}
