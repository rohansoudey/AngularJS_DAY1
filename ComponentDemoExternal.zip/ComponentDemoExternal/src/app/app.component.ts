import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1>Helo {{name}}</h1><br><my-component></my-component>`,
})
export class AppComponent  { name = 'Angular'; }
