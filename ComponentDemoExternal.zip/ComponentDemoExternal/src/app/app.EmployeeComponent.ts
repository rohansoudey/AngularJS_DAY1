import {Component} from '@angular/core';
@Component({
	
	selector:'<my-component></my-component>',
	templateUrl:'./EmployeeComponent.html'
})
export class AppEmployeeComponent
{
	empId:number=1;
	empName:string="Ashutosh";
	empDepartment:string="Java Core";
}