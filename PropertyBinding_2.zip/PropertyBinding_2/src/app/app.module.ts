import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';

import { FormsModule} from '@angular/forms';


import { AppEmployeeComponent }  from './app.EmployeeComponent';

@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [ AppComponent,AppEmployeeComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
