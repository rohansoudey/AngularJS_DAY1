import {Component} from '@angular/core';
@Component({
	
	selector:'<my-component></my-component>',
	templateUrl:'./EmployeeComponent.html'
})
export class AppEmployeeComponent
{
	/*empId:number=1;
	empName:string="Ashutosh";
	empDepartment:string="Java Core";
	isDisabled:string='true';*/
	
	status:boolean=false;
	
	onclick():void{
		console.log('Welcome to EVENT');
		alert("Hello world");
	}
	show():void{
		this.status=!this.status;
	}
}